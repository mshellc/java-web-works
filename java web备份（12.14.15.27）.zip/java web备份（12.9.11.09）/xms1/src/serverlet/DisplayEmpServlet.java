package serverlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.com.xms1.dao.Userlmpl;
import cn.com.xms1.po.User;

/**
 * Servlet implementation class DisplayEmpServlet
 */
@WebServlet("/DisplayEmpServlet")
public class DisplayEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayEmpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String empid=request.getParameter("empid");
		
		String ename=request.getParameter("ename");
		String password=request.getParameter("password");
		String egender=request.getParameter("egender");
		String depid=request.getParameter("depid");
		User user=new User();
		
		user.setEmpid(empid);
		user.setEgender(egender);
		user.setPassword(password);
		user.setEname(ename);
		user.setDepid(depid);
		Userlmpl ui= new Userlmpl();
		if(!ui.select(empid)){
			response.sendRedirect("displayemp.jsp");
		}
		else{
			response.getWriter().append("<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"></head><body><script>alert(\"����ʧ��\"); window.history.back();</script></body></html>");
		}
	}

}
