package serverlet;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.com.xms1.dao.Userlmpl;
import cn.com.xms1.po.User;

/**
 * Servlet implementation class AddEmpServlet
 */
@WebServlet("/AddEmpServlet")
public class AddEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddEmpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("UTF-8");
		response.getWriter().append("<html><head> <meta charset=\"UTF-8\" /></head><body>");
		
		String ename=request.getParameter("ename");
		String password= request.getParameter("password");
		Userlmpl ui= new Userlmpl();
		User user =ui.getUserByUsername(ename);
		if(user==null){
			response.getWriter().append("username is not exist �û���������");
		}else{
			if(password.equals(user.getPassword())){
			   HttpSession session=request.getSession();
			   session.setAttribute("ename",user.getEname());
				response.getWriter().append("success!!!��¼�ɹ�����ӭ��"+ename);
				response.getWriter().append("<script>location.href=\"user/userlist.jsp\"</script>");
			}else{
				response.getWriter().append("password error �������");
			}
		}
		response.getWriter().append("</body></html>");
		//response.getWriter().append("do post "+username+" mima:"+password);
	}
	}

