package cn.com.xms1.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DbUtil {
	private static String drivers="com.mysql.jdbc.Driver";

	
	private static String url = "jdbc:mysql://localhost:3306/mydb1?"
             + "user=root&password=&useUnicode=true&characterEncoding=UTF8";


	public static Connection getConnection() throws SQLException {
		Connection conn = null;
		try {
			Class.forName(drivers).newInstance();
			conn=DriverManager.getConnection(url);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (conn == null) {
			throw new SQLException("com.system.util.db.DBUtils: Cannot get connection.");
		}
		return conn;
	}

	public static void close(Connection conn) {
		if (conn == null)
			return;
		try {
			conn.close();
		} catch (SQLException e) {
			System.out.println("com.system.util.db.DBUtils: Cannot close connection.");
		}
	}

	public static void close(Statement stmt) {
		try {
			if (stmt != null) {
				stmt.close();
			}
		} catch (SQLException e) {
			System.out.println("com.system.util.db.DBUtils: Cannot close statement.");
		}

	}

	public static void close(ResultSet rs) {
		try {
			if (rs != null) {
				rs.close();
			}
		} catch (SQLException e) {
			System.out.println("com.system.util.db.DBUtils: Cannot close resultset.");
		}
	}

}
