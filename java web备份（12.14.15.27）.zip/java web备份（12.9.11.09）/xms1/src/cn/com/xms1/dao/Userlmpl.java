package cn.com.xms1.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import cn.com.xms1.po.User;

import cn.com.xms1.db.DbUtil;

public class Userlmpl {
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	public Userlmpl(){
		 
		 try {
			con=DbUtil.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();		
		}
	}
	public boolean insert(User user) throws SQLException{
		String sql="INSERT INTO employee (`ename`, `password`, `egender`,`depid`) VALUES(?,?,?,?) ;";
        ps=con.prepareStatement(sql);
        int i=0;
        ps.setString(++i,user.getEname());   
        ps.setString(++i,user.getPassword());
        ps.setString(++i,user.getEgender());
        ps.setString(++i,user.getDepid());
        return ps.execute();
	}
	public boolean update(User user){
		String sql="update employee set ename=?,password=?, egender=?,depid=? where empid=? ;";
        try {
			ps=con.prepareStatement(sql);
			int i=0;
	        ps.setString(++i,user.getEname());
	        ps.setString(++i,user.getPassword());
	        ps.setString(++i,user.getEgender());
	        ps.setString(++i,user.getDepid());
	        ps.setString(++i,user.getEmpid());
	        return ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return true;
		}
	}
	
	public boolean delete(String empid){
		String sql="DELETE FROM employee WHERE empid=?";
		 try {
				ps=con.prepareStatement(sql);
				int i=0;
		        ps.setString(++i,empid);
		        
		        return ps.execute();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return true;
			}
		
	}
	
	public boolean select(String empid){
		User user = new User();
		String sql = "SELECT * FROM employee WHERE empid=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1,empid);
			rs=ps.executeQuery();
			if(rs.next()){
		    	user.setEmpid(empid);
			    user.setEname(rs.getString("ename"));
			    user.setEgender(rs.getString("egender"));
			    user.setDepid(rs.getString("depid"));
			    user.setPassword(rs.getString("password"));
			 
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return true;
		
			}

	public User getUserById(String empid){
		User user = new User();
		String sql = "SELECT * FROM employee WHERE empid=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1,empid);
			rs=ps.executeQuery();
			if(rs.next()){
		    	user.setEmpid(empid);
			    user.setEname(rs.getString("ename"));
			    user.setEgender(rs.getString("egender"));
			    user.setDepid(rs.getString("depid"));
			    user.setPassword(rs.getString("password"));
			 
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return user;
		
	}
	
	public User getUserByUsername(String ename){
		User user=null;
		String sql = "SELECT * FROM employee WHERE ename=?";
		try {
			
			ps=con.prepareStatement(sql);
			ps.setString(1, ename);
			rs=ps.executeQuery();
			if(rs.next()){
			    user = new User();
		    	user.setEmpid(rs.getString("empid"));
			    user.setEname(rs.getString("ename"));
			    user.setEgender(rs.getString("egender"));
			    user.setDepid(rs.getString("depid"));
			    user.setPassword(rs.getString("password"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return user;
		
	}
	
	public ArrayList getAllUser(){
		String sql = "SELECT * FROM employee INNER JOIN department ON employee.`depid`=department.`depid` ";
		ArrayList list= new ArrayList();
		try {
			
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			User user;
			while(rs.next()){
		    	user= new User();
				user.setEmpid(rs.getString("empid"));
			    user.setEname(rs.getString("ename"));
			    user.setPassword(rs.getString("password"));
			    user.setEgender(rs.getString("egender"));
			    user.setDepid(rs.getString("depid"));
			    user.setDname(rs.getString("dname"));
			    list.add(user);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
	
	public int getRows(String swhere){
		String sql = "SELECT count(*) FROM employee INNER JOIN department ON employee.`depid`=department.`depid` "+swhere;
    try {
			
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			if(rs.next()){
		    	 return rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      return 0;
	}
	
	public ArrayList getUsersByPage(String swhere,int offset,int pagesize){
		String sql = "SELECT * FROM employee,department WHERE employee.`depid`=department.`depid` "+swhere+" limit "+offset+" , "+pagesize;
		ArrayList list= new ArrayList();
		try {
			
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			User user;
			while(rs.next()){
		    	user= new User();
		    	user.setEmpid(rs.getString("empid"));
			    user.setEname(rs.getString("ename"));
			    user.setPassword(rs.getString("password"));
			    user.setEgender(rs.getString("egender"));
			    user.setDepid(rs.getString("depid"));
			    user.setDname(rs.getString("dname"));
			    list.add(user);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
	
	
	
	public void close(){
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) throws SQLException {
		Userlmpl ui= new Userlmpl();
		User user=new User();
       
		user.setEname("aaabc11112");
		user.setPassword("1234563sabbba");
		user.setEgender("0");
		user.setEmpid("2");
		user.setDepid("1");
		  //ui.delete("2");
		 ui.update(user);
		//System.out.println(ui.insert(user));
		
		
	}
	}

