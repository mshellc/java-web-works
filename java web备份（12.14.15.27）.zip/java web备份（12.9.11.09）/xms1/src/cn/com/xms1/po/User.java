package cn.com.xms1.po;

public class User {
	 private String  empid;
	 private String  ename;
	 private String  egender;
	 private String  depid;
	 private String  dname;
	 private String  password;
	 public String getEmpid(){
		 return empid;
	 }
	 public void setEmpid(String empid) {
			this.empid = empid;
		}
	 public String getEname() {
			return ename;
		}
	 public void setEname(String ename) {
			this.ename = ename;
		}
	 public String getEgender() {
			return egender;
		}
		public void setEgender(String egender) {
			this.egender = egender;
		}
		public String getDepid() {
			return depid;
		}
		public void setDepid(String depid) {
			this.depid = depid;
		}
		public String getDname() {
			return dname;
		}
		public void setDname(String dname) {
			this.dname = dname;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		@Override
		public String toString() {
			return "User [empid=" + empid + ", ename=" + ename +  ", password=" + password+", egender=" + egender + ", depid=" + depid + ", dname=" +dname + "]";
		}
}
