/*
SQLyog Ultimate v11.27 (32 bit)
MySQL - 5.6.12-log : Database - mydb1
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`mydb1` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_bin */;

USE `mydb1`;

/*Table structure for table `department` */

DROP TABLE IF EXISTS `department`;

CREATE TABLE `department` (
  `depid` int(11) NOT NULL COMMENT '部门编号',
  `dname` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '部门名称',
  PRIMARY KEY (`depid`,`dname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `department` */

insert  into `department`(`depid`,`dname`) values (1,'人力资源'),(2,'市场'),(3,'财务'),(4,'后勤');

/*Table structure for table `employee` */

DROP TABLE IF EXISTS `employee`;

CREATE TABLE `employee` (
  `empid` int(11) NOT NULL AUTO_INCREMENT,
  `ename` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `egender` tinyint(4) DEFAULT NULL COMMENT '1男0女',
  `depid` int(11) DEFAULT NULL,
  PRIMARY KEY (`empid`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

/*Data for the table `employee` */

insert  into `employee`(`empid`,`ename`,`password`,`egender`,`depid`) values (1,'ms','15230557',0,2),(6,'kkk','123456',0,1),(7,'ll','11',1,3),(8,'fsd','123',1,1),(10,'谢明森',NULL,0,1),(20,'礼拜六','123',1,3),(22,'哈哈','123',0,3),(23,'地方','123',1,1),(24,'asd','asdd',1,1),(25,'sdasdsadasdasdas','qwer',0,2),(26,'sdasd','1996',1,1),(27,'lllllll','12121',1,1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
