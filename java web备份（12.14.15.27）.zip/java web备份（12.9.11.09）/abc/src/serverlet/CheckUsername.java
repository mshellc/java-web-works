package serverlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.*;
import cn.com.sdpt.dao.UserImpl;;

/**
 * Servlet implementation class CheckUsername
 */
@WebServlet("/user/CheckUsername")
public class CheckUsername extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckUsername() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("UTF-8");
		String username =request.getParameter("username");
		UserImpl ui =new UserImpl();
		 JSONObject json = new JSONObject();   
		if(ui.checkUsernameIsExist(username)){
			//�û�������
			 
			  json.put("result","�û����Ѿ�ע���ˣ�");
		}
		else{
			//�û��������� 
			json.put("result","�û�������ע��");
		}
		response.getWriter().append(json.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("UTF-8");
		String username =request.getParameter("username");
		UserImpl ui =new UserImpl();
		 JSONObject json = new JSONObject();   
		if(ui.checkUsernameIsExist(username)){
			//�û�������
			 
			  json.put("result","�û����Ѿ�ע���ˣ�");
		}
		else{
			//�û��������� 
			json.put("result","�û�������ע��");
		}
		response.getWriter().append(json.toString());
		//doGet(request, response);
	}

}
