package serverlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.com.sdpt.dao.UserImpl;
import cn.com.sdpt.po.User;

/**
 * Servlet implementation class UserUpdateSave
 */
@WebServlet("/user/UserUpdateSave")
public class UserUpdateSave extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserUpdateSave() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String userid=request.getParameter("userid");
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String realname=request.getParameter("realname");
		String gender=request.getParameter("gender");
		String birthday=request.getParameter("birthday");
		User user=new User();
		user.setBirthday(birthday);
		user.setUserid(userid);
		user.setGender(gender);
		user.setPasswd(password);
		user.setRealname(realname);
		user.setUsername(username);
		UserImpl ui= new UserImpl();
		if(!ui.update(user)){
			response.getWriter().append("<script>alert(\"�޸ĳɹ���\");</script>");	
			response.sendRedirect("userlist.jsp");
		}
		else{
			response.getWriter().append("<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"></head><body><script>alert(\"����ʧ��\"); window.history.back();</script></body></html>");
		}
		
	}

}
