package test;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.Test;

import cn.com.sdpt.dao.UserImpl;
import cn.com.sdpt.po.User;

public class UserImplTest {
	UserImpl ui= new UserImpl();
	User user=new User();
	@Test
	public void testInsert() {
		user.setUsername("aaabc11112");
		user.setPasswd("1234563sabbba");
		user.setRealname("hell world111");
		user.setGender("0");
		user.setBirthday("2002-11-2");
		 
		try {
			ui.insert(user);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testUpdate() {
		user.setUsername("abc");
		user.setPasswd("123=ba");
		user.setRealname("hell wosssss11");
		user.setGender("1");
		user.setBirthday("2032-11-2");
		user.setUserid("4");
		ui.update(user);
	}

	@Test
	public void testGetUser() {
		 user=ui.getUserById("4");
		 System.out.println(user.toString());
	}
	
	@Test
	public void testGetAllUser() {
		ArrayList list= ui.getAllUser();
		for(int i=0;i<list.size();i++){
			User user=(User)list.get(i);
			
			System.out.println(user.toString());
		}
		 
	}
	
	@Test
	public void testDelete() {
		 String userid="5";
		 ui.delete(userid);
	}

}
