package cn.com.sdpt.po;

public class User {
	  private String userid;
	  private String username;
	  private String passwd;
	  private String realname;
	  private String gender;
	  private String  regdate;
	  private String birthday;
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getRealname() {
		return realname;
	}
	public void setRealname(String realname) {
		this.realname = realname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	@Override
	public String toString() {
		return "User [userid=" + userid + ", username=" + username + ", passwd=" + passwd + ", realname=" + realname
				+ ", gender=" + gender + ", regdate=" + regdate + ", birthday=" + birthday + "]";
	}
	  
	  

}
