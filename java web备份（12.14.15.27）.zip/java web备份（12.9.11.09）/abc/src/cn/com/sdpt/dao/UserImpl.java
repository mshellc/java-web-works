package cn.com.sdpt.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import cn.com.sdpt.db.DbUtil;
import cn.com.sdpt.po.User;



public class UserImpl {
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;
	public UserImpl(){
		 
		 try {
			con=DbUtil.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();		
		}
	}
	public boolean insert(User user) throws SQLException{
		String sql="INSERT INTO usertb (`username`, `passwd`,`realname`, `gender`, `regdate`,`birthday`) VALUES(?,?, ?,?, now(),?) ;";
        ps=con.prepareStatement(sql);
        int i=0;
        ps.setString(++i,user.getUsername());
        ps.setString(++i,user.getPasswd());
        ps.setString(++i,user.getRealname());
        ps.setString(++i,user.getGender());
        ps.setString(++i,user.getBirthday());
        return ps.execute();
        		
	}
	
	public boolean update(User user){
		String sql="update usertb set username=?,passwd=?,realname=?, gender=?,birthday=? where userid=? ;";
        try {
			ps=con.prepareStatement(sql);
			int i=0;
	        ps.setString(++i,user.getUsername());
	        ps.setString(++i,user.getPasswd());
	        ps.setString(++i,user.getRealname());
	        ps.setString(++i,user.getGender());
	        ps.setString(++i,user.getBirthday());
	        ps.setString(++i,user.getUserid());
	        return ps.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return true;
		}
         
	}
	
	public boolean delete(String userid){
		String sql="DELETE FROM usertb WHERE userid=?";
		 try {
				ps=con.prepareStatement(sql);
				int i=0;
		        ps.setString(++i,userid);
		        
		        return ps.execute();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return true;
			}
		
	}

	public User getUserById(String userid){
		User user = new User();
		String sql = "SELECT * FROM usertb WHERE userid=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1,userid);
			rs=ps.executeQuery();
			if(rs.next()){
		    	user.setUserid(userid);
			    user.setUsername(rs.getString("username"));
			    user.setBirthday(rs.getString("birthday"));
			    user.setGender(rs.getString("gender"));
			    user.setRealname(rs.getString("realname"));
			    user.setRegdate(rs.getString("regdate"));
			    user.setPasswd(rs.getString("passwd"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return user;
		
	}
	
   /*
    * ���������û����ж����ݿ����Ƿ����
    * ��������û�������true
    * �����ڷ���false
    */
	public boolean checkUsernameIsExist(String username){
		String sql = "SELECT * FROM usertb WHERE username=?";
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1,username);
			rs=ps.executeQuery();
			if(rs.next()){
		    	 return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
		
	}
	
	
	public User getUserByUsername(String username){
		User user=null;
		String sql = "SELECT * FROM usertb WHERE username=?";
		try {
			
			ps=con.prepareStatement(sql);
			ps.setString(1, username);
			rs=ps.executeQuery();
			if(rs.next()){
			    user = new User();
		    	user.setUserid(rs.getString("userid"));
			    user.setUsername(rs.getString("username"));
			    user.setBirthday(rs.getString("birthday"));
			    user.setGender(rs.getString("gender"));
			    user.setRealname(rs.getString("realname"));
			    user.setRegdate(rs.getString("regdate"));
			    user.setPasswd(rs.getString("passwd"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return user;
		
	}
	
	
	public ArrayList getAllUser(){
		String sql = "SELECT * FROM usertb ";
		ArrayList list= new ArrayList();
		try {
			
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			User user;
			while(rs.next()){
		    	user= new User();
				user.setUserid(rs.getString("userid"));
			    user.setUsername(rs.getString("username"));
			    user.setBirthday(rs.getString("birthday"));
			    user.setGender(rs.getString("gender"));
			    user.setRealname(rs.getString("realname"));
			    user.setRegdate(rs.getString("regdate"));
			    user.setPasswd(rs.getString("passwd"));
			    list.add(user);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
	
	public int getRows(String swhere){
		String sql = "SELECT count(*) FROM usertb "+swhere;
    try {
			
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			if(rs.next()){
		    	 return rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      return 0;
	}
	
	public ArrayList getUsersByPage(String swhere,int offset,int pagesize){
		String sql = "SELECT * FROM usertb where 1=1 "+swhere+" limit "+offset+" , "+pagesize;
		ArrayList list= new ArrayList();
		try {
			
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			User user;
			while(rs.next()){
		    	user= new User();
				user.setUserid(rs.getString("userid"));
			    user.setUsername(rs.getString("username"));
			    user.setBirthday(rs.getString("birthday"));
			    user.setGender(rs.getString("gender"));
			    user.setRealname(rs.getString("realname"));
			    user.setRegdate(rs.getString("regdate"));
			    user.setPasswd(rs.getString("passwd"));
			    list.add(user);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
	
	
	
	
	public void close(){
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) throws SQLException {
		UserImpl ui= new UserImpl();
		User user=new User();
       
		user.setUsername("aaabc11112");
		user.setPasswd("1234563sabbba");
		user.setRealname("hell world111");
		user.setGender("0");
		user.setBirthday("2002-11-2");
		user.setUserid("2");
		  ui.delete("2");
		 // ui.update(user);
		//System.out.println(ui.insert(user));
		
		
	}
}
